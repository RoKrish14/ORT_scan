import os
import subprocess
import webbrowser
from flask import Flask, render_template, request
import tkinter as tk
from tkinter import filedialog
import requests

app = Flask(__name__)
selected_folder = ""

def detect_build_tool(project_path):
    for root, dirs, files in os.walk(project_path):
        if "pom.xml" in files:
            return "maven"
        elif "package.json" in files:
            return "npm"
        elif "build.gradle" in files:
            return "gradle"
        elif "requirements.txt" in files:
            return "pip"
    return "unknown"

def upload_sbom_to_dependency_track(sbom_path):
    api_url = "http://localhost:8080/api/v1/bom"
    api_key = "odt_XVNZO5Fo_W8zHRKRBspvhSV0ycSIrjel0Ail7kmrV"
    project_uuid = "0c9da6c9-95d1-434e-b902-2860891d7a2e"
    with open(sbom_path, 'rb') as sbom_file:
        response = requests.put(
            api_url,
            headers={"X-API-Key": api_key},
            files={
                "project": (None, project_uuid),
                "bom": ("bom.xml", sbom_file, "application/xml")
            }
        )
    return response.status_code == 200

def run_ort(project_path, output_path):
    ort_cmd = f'./cli/build/install/ort/bin/ort analyze -i "{project_path}" -o "{output_path}"'
    subprocess.run(ort_cmd, shell=True)
    sbom_cmd = f'./cli/build/install/ort/bin/ort reporter -i "{output_path}/analyzer-result.yml" -o "{output_path}" -f CycloneDx'
    subprocess.run(sbom_cmd, shell=True)

    sbom_file_path = os.path.join(output_path, "bom.xml")
    if os.path.exists(sbom_file_path):
        upload_success = upload_sbom_to_dependency_track(sbom_file_path)
        print("Upload to Dependency-Track:", "Success" if upload_success else "Failed")

@app.route('/', methods=['GET', 'POST'])
def index():
    global selected_folder
    if request.method == 'POST':
        path = request.form['project_path']
        output_path = os.path.join(path, "ort-output")
        os.makedirs(output_path, exist_ok=True)
        tool = detect_build_tool(path)
        run_ort(path, output_path)
        return render_template("result_template.html", build_tool=tool, path=output_path)
    return render_template("gui.html", prefill_path=selected_folder)

if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    selected_folder = filedialog.askdirectory(title="Select a project folder to scan")
    webbrowser.open("http://127.0.0.1:5000")
    app.run(debug=False)
