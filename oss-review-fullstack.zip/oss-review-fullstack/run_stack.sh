#!/bin/bash
set -e

mkdir -p reports ort-results

echo "🔧 Running Syft to generate SBOM..."
syft dir:. -o spdx-json > reports/sbom.spdx.json

echo "🛡️ Running Trivy to scan for vulnerabilities..."
trivy fs . --format json --output reports/trivy-report.json

echo "🔍 Running ScanCode Toolkit..."
scancode --license --copyright --info --json-pp reports/scancode-report.json .

echo "🔬 Running ORT toolchain..."
ort analyze -i . -o ort-results/analyzer
ort scan -i ort-results/analyzer/analyzer-result.yml -o ort-results/scanner
ort evaluate -i ort-results/scanner -o ort-results/evaluator
ort report -i ort-results/evaluator -o ort-results/report -f WebApp,SpdxDocument,CycloneDx,StaticHtml

echo "✅ All tools completed successfully."
echo "📂 Reports saved in 'reports/' and 'ort-results/'"
echo "🌐 You can now run 'docker-compose up --build' to launch the Web UI at http://localhost:3000"
