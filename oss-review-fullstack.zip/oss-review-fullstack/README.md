# Dockerized OSS Review Stack: Trivy + ORT + ScanCode + Syft + Web UI

This project sets up a full open source review stack using:

- ✅ Trivy (vulnerability scanner)
- ✅ Syft (SBOM generator)
- ✅ ScanCode Toolkit (license and metadata scanner)
- ✅ ORT (compliance and evaluation tool)
- ✅ ORT Web App (dashboard)

---

## 📦 Prerequisites

- Docker & Docker Compose installed
- Node.js (only for building ORT Web App)

---

## 🚀 Usage

1. **Clone the ORT Web App:**
   ```
   git clone https://github.com/oss-review-toolkit/ort-web-app.git
   ```

2. **Place it inside this folder as `ort-web-app/`**
   (so it can be Dockerized for the frontend)

3. **Run the full OSS scanning toolchain:**
   ```
   chmod +x run_stack.sh
   ./run_stack.sh
   ```

4. **Launch the Web UI:**
   ```
   docker-compose up --build
   ```

5. **Open your browser:**
   ```
   http://localhost:3000
   ```

6. **Upload ORT result files:**
   - `ort-results/evaluator/evaluator-result.yml`
   - Optionally: `analyzer-result.yml`, `scan-result.yml`

---

## 📁 Outputs

- `reports/`: Contains SBOM, Trivy, and ScanCode outputs
- `ort-results/`: Contains full ORT evaluation + reports
- `index.html` from `StaticHtml` is a quick offline view

---

## 🧼 Cleanup

```
docker-compose down
docker system prune -f
```
