# ORT Web App (Dockerized)

This Docker setup allows you to build and run the OSS Review Toolkit (ORT) Web App with minimal effort.

---

## ✅ Prerequisites

- Docker installed (https://docs.docker.com/get-docker/)
- (Optional) Docker Compose installed

---

## 🚀 Quickstart

### 1. Clone the ORT Web App source:

```
git clone https://github.com/oss-review-toolkit/ort-web-app.git
cd ort-web-app
```

### 2. Copy these Docker files into the cloned folder:

- Dockerfile
- docker-compose.yml
- .dockerignore

### 3. Build and run using Docker:

#### Option A: Docker CLI

```
docker build -t ort-web-app .
docker run -p 3000:3000 ort-web-app
```

#### Option B: Docker Compose

```
docker-compose up --build
```

### 4. Open in Browser:

```
http://localhost:3000
```

### 5. Upload the following files from your pipeline:

- `evaluator-result.yml`
- `scan-result.yml`
- `analyzer-result.yml`

These will be visualized through the interactive dashboard.

---

## 🛠 Notes

- You can pre-copy result files and mount them with volumes if desired.
- Built app is served using `serve`, a static file server for Node.js.
- Port `3000` is exposed by default.

