# ORT GUI Tool

## Features
- Detects build tool (Maven, NPM, Gradle, Pip)
- Runs OSS Review Toolkit
- Generates CycloneDX SBOM
- Local HTML GUI

## Setup

1. Install Python 3.10+ and Flask:
    ```
    pip install flask
    ```

2. Build ORT CLI with:
    ```
    ./gradlew installDist
    ```

3. Place the built ORT CLI under `cli/` directory.

4. Run the app:
    ```
    python ort_runner.py
    ```

5. OR package as `.exe` with:
    ```
    pyinstaller --noconsole --add-data "templates;templates" --add-data "static;static" ort_runner.py
    ```

## Usage

Enter the full path of your project to scan, and it will:
- Detect the build system
- Run OSS Review Toolkit
- Generate an SBOM and display results
