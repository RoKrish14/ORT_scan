import os
import subprocess
import webbrowser
from flask import Flask, render_template, request
import threading
import tkinter as tk
from tkinter import filedialog

app = Flask(__name__)

def detect_build_tool(project_path):
    files = os.listdir(project_path)
    if "pom.xml" in files:
        return "maven"
    elif "package.json" in files:
        return "npm"
    elif "build.gradle" in files:
        return "gradle"
    elif "requirements.txt" in files:
        return "pip"
    else:
        return "unknown"

def run_ort(project_path, output_path):
    ort_cmd = f'./cli/build/install/ort/bin/ort analyze -i "{project_path}" -o "{output_path}"'
    subprocess.run(ort_cmd, shell=True)

    sbom_cmd = f'./cli/build/install/ort/bin/ort reporter -i "{output_path}/analyzer-result.yml" -o "{output_path}" -f CycloneDx'
    subprocess.run(sbom_cmd, shell=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        path = request.form['project_path']
        output_path = os.path.join(path, "ort-output")
        os.makedirs(output_path, exist_ok=True)
        tool = detect_build_tool(path)
        run_ort(path, output_path)
        return render_template("result_template.html", build_tool=tool, path=output_path)
    return render_template("gui.html")

def open_browser():
    webbrowser.open("http://127.0.0.1:5000")

if __name__ == '__main__':
    threading.Timer(1.25, open_browser).start()
    app.run(debug=False)

@app.route('/select-folder')
def select_folder():
    root = tk.Tk()
    root.withdraw()
    folder_selected = filedialog.askdirectory()
    return folder_selected
